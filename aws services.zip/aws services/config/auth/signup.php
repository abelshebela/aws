<?php 

require 'db.php';
$error_firstname="";
$error_lastname="";
$error_username=$mobile_error=$error_email=$error_pass= $error_confirm="";

if(isset($_POST['submit'])){
     
   
    $user=trim($_POST['name']);
    $email=trim($_POST['email']);
    $password=trim($_POST['password']);
   
    if($user==""){
        $error_username="Please enter user name";
        
        
        exit();
    }
    elseif(strlen($user)<5){
        $error_username="Username should be atleast five characters.";
        
        
        exit();
    }
    elseif($email==""){
        $error_email="Please enter your email";
       
        exit();
    }
    elseif(!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $email)){
        $error_email="Please enter valide email, like your@abc.com";
        
        exit();
    }
    elseif($password==""){
        $error_pass= "Please enter password";
        
        
        exit();
    }
    
  
    else{
        $hashedPass = password_hash($password, PASSWORD_DEFAULT);
        $sql="INSERT INTO users( userName,email, password) VALUES('$user','$email','$hashedPass');";
        mysqli_query($conn,$sql);
       header("Location: ../../index.php");
          exit();  

}
}


?>